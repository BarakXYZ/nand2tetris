import java.io.*;

class JackCompiler {
    public static void main(String[] args) throws FileNotFoundException {
        JackAnalyzer.main(args);
    }
}
