enum Kind {
    FIELD,
    STATIC,
    LOCAL,
    ARGUMENT
}
