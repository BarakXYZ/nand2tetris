=================== MEMORY GAME =====================

A simple game where you will be shown some characters
and then you have to type a string of all of them.
If guessed correctly you advance to the next round 
and if not the game ends. 

Gussing correctly leads to the next round where 
no. of characters increase by 1.

There are 3 modes:-
1) EASY (alphabets only)
2) MEDIUM (alphnumeric)
3) HARD (any character)

***
Run the game by downloading the code then use online Web IDE or
download the suite.

Enjoy!!!