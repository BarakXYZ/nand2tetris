// Implemented by BarakXYZ 2024

#ifndef PUSH_POP_COMMANDS_H
#define PUSH_POP_COMMANDS_H

#include "PushPopSegment.h"
#include "PushConstant.h"
#include "PushPopStatic.h"
#include "PushPopTemp.h"
#include "PushPopPointer.h"

#endif
