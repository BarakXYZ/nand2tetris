// Implemented by BarakXYZ 2024

#ifndef PROGRAM_CONTROL_COMMANDS_H
#define PROGRAM_CONTROL_COMMANDS_H

#include "Booting.h"
#include "BranchingCommands.h"
#include "WriteCallCommand.h"
#include "WriteFunctionCommand.h"
#include "WriteReturnCommand.h"

#endif
