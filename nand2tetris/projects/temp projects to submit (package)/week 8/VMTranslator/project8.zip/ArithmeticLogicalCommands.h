// Implemented by BarakXYZ 2024

#ifndef ARITHMETIC_LOGICAL_COMMANDS_H
#define ARITHMETIC_LOGICAL_COMMANDS_H

#include "LogicalCommandsEQ.h"
#include "LogicalCommandsGT.h"
#include "LogicalCommandsLT.h"
#include "LogicalAndOrNot.h"
#include "ArithmeticCommands.h"

#endif
