# Build the Project:

1. From the JackAnalyzer folder execute:

```bash
mkdir build && cd build && cmake ..
```

2. Build:

```bash
cmake --build .
```

3. Test run a program:

```bash
./JackAnalzyer ../../Seven
```

You should now see an xml output file in the dir of the program analyzed.
